"""nuPlan adapter with explicit scene-source modes.

Real nuPlan mode never falls back to synthetic data.  Synthetic mode is provided
only for deterministic smoke tests and marks records as ``source='synthetic'``.
"""
from __future__ import annotations

import glob
import hashlib
import importlib.util
import json
import math
import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Sequence

from capplan.data.schemas import EpisodeMetadata, Pose2D, SceneRecord


@dataclass
class NuPlanScenarioRecord:
    episode: EpisodeMetadata
    scene: SceneRecord
    ego_history: List[Dict]
    agent_history: List[Dict]
    map_context: Dict
    route_corridor: Dict


class _LocalNuPlanWorker:
    """Minimal worker object compatible with nuPlan's ``worker_map`` helper.

    Some nuPlan devkit versions call ``worker.number_of_threads`` before using
    the scenario builder.  Passing ``None`` therefore crashes with
    ``AttributeError: 'NoneType' object has no attribute 'number_of_threads'``.
    This lightweight adapter keeps the default path sequential when
    ``num_workers == 0`` and enables simple threaded mapping when requested.
    """

    def __init__(self, num_workers: int = 0) -> None:
        self.number_of_threads = max(0, int(num_workers))

    def map(self, task: Any, items: Iterable[Any]) -> List[Any]:
        if self.number_of_threads == 0:
            return [task(item) for item in items]
        with ThreadPoolExecutor(max_workers=self.number_of_threads) as executor:
            return list(executor.map(task, items))


def _split_path_list(value: str | Sequence[str] | None) -> List[str]:
    """Split CLI-style nuPlan DB inputs into path-like tokens.

    Supported forms:
    - one absolute/relative path string;
    - comma-separated paths;
    - plus-separated paths, e.g. ``train_boston+train_pittsburgh``;
    - a Python sequence already produced by argparse.
    """
    if value is None:
        return []
    raw = list(value) if isinstance(value, (list, tuple, set)) else [str(value)]
    pieces: List[str] = []
    for item in raw:
        for part in re.split(r"[,+]", str(item)):
            part = part.strip()
            if part:
                pieces.append(part)
    return pieces


def expand_nuplan_db_files(db_files: str | Sequence[str] | None) -> List[str]:
    """Expand nuPlan DB file/folder/glob inputs into concrete ``.db`` files.

    The official nuPlan scenario builder expects database files in most devkit
    versions.  This helper accepts either individual ``.db`` files or folders
    containing DB sets, including folders such as ``train_boston`` and
    ``train_pittsburgh`` under a cache root.  It is intentionally strict: an
    existing folder with no ``.db`` files is treated as a configuration error
    instead of silently producing an empty/synthetic dataset.
    """
    expanded: List[str] = []
    for token in _split_path_list(db_files):
        matches = sorted(glob.glob(token)) if any(ch in token for ch in "*?[]") else [token]
        if not matches:
            raise RuntimeError(f"nuPlan DB pattern matched no files: {token}")
        for match in matches:
            path = Path(match)
            if path.is_dir():
                dbs = sorted(path.rglob("*.db"))
                if not dbs:
                    raise RuntimeError(f"nuPlan DB directory contains no .db files: {path}")
                expanded.extend(str(p) for p in dbs)
            else:
                expanded.append(str(path))
    # De-duplicate while preserving deterministic order.
    seen = set()
    out: List[str] = []
    for item in expanded:
        if item not in seen:
            out.append(item)
            seen.add(item)
    return out


def safe_call(obj: Any, names: List[str], default: Any = None) -> Any:
    for name in names:
        try:
            attr = getattr(obj, name)
        except Exception:
            # Some nuPlan properties (notably map_api) execute map-db loading
            # during attribute access. ``hasattr`` would re-raise non-
            # AttributeError failures before our safety wrapper can handle them.
            continue
        try:
            return attr() if callable(attr) else attr
        except TypeError:
            continue
        except Exception:
            continue
    return default


class NuPlanAdapter:
    def __init__(
        self,
        scene_source: str = "synthetic",
        data_root: str | None = None,
        map_root: str | None = None,
        sensor_root: str | None = None,
        db_files: str | Sequence[str] | None = None,
        map_version: str | None = None,
        split: str = "mini",
        seed: int = 0,
        num_workers: int = 0,
        scenario_types: Sequence[str] | str | None = None,
        map_names: Sequence[str] | str | None = None,
        log_names: Sequence[str] | str | None = None,
        timestamp_threshold_s: float | None = None,
        ego_displacement_minimum_m: float | None = None,
        allow_synthetic_fallback: bool = False,
        # Legacy alias accepted for older scripts; does not imply fallback.
        nuplan_root: str | None = None,
    ) -> None:
        if scene_source not in {"synthetic", "nuplan"}:
            raise ValueError("scene_source must be 'synthetic' or 'nuplan'")
        if nuplan_root and not data_root:
            data_root = nuplan_root
        self.scene_source = scene_source
        self.data_root = data_root
        self.map_root = map_root
        self.sensor_root = sensor_root
        self.db_files_requested = db_files
        self.db_files = expand_nuplan_db_files(db_files) if scene_source == "nuplan" and db_files else ([] if scene_source == "nuplan" else db_files)
        self.map_version = map_version
        self.split = split
        self.seed = seed
        self.num_workers = max(0, int(num_workers))
        self.scenario_types = _split_path_list(scenario_types)
        self.map_names = _split_path_list(map_names)
        self.log_names = _split_path_list(log_names)
        self.timestamp_threshold_s = None if timestamp_threshold_s is None else float(timestamp_threshold_s)
        self.ego_displacement_minimum_m = None if ego_displacement_minimum_m is None else float(ego_displacement_minimum_m)
        self.allow_synthetic_fallback = allow_synthetic_fallback
        self.nuplan_available = self._check_nuplan()
        self._builder = None
        self._worker = _LocalNuPlanWorker(self.num_workers)
        # Roadblock/lane geometry is immutable for a map and heavily reused
        # across nearby nuPlan scenarios. Cache extracted coordinates, not map
        # objects, so route construction keeps identical geometry semantics
        # without repeated GPKG object traversal.
        self._route_object_points_cache: Dict[tuple[str, str], tuple[tuple[float, float], ...]] = {}
        self._route_geometry_cache_hits = 0
        self._route_geometry_cache_misses = 0
        if self.scene_source == "nuplan":
            self._init_nuplan_or_raise()
        elif self.scene_source == "synthetic":
            self._init_synthetic()
        else:  # defensive
            raise RuntimeError("unreachable scene source")

    @staticmethod
    def _check_nuplan() -> bool:
        return importlib.util.find_spec("nuplan") is not None

    def _init_synthetic(self) -> None:
        self._builder = None

    def _init_nuplan_or_raise(self) -> None:
        missing_args = [name for name, value in {
            "nuplan_data_root": self.data_root,
            "nuplan_map_root": self.map_root,
            "nuplan_db_files": self.db_files,
            "nuplan_map_version": self.map_version,
        }.items() if not value]
        if missing_args:
            raise RuntimeError(f"scene_source=nuplan requires real nuPlan paths: missing {', '.join(missing_args)}")
        if not self.nuplan_available:
            raise RuntimeError("scene_source=nuplan requested, but the nuPlan devkit is not installed; no synthetic fallback is allowed")
        for label, path in [("nuplan_data_root", self.data_root), ("nuplan_map_root", self.map_root)]:
            if path and not Path(path).exists():
                raise RuntimeError(f"scene_source=nuplan requested, but {label} does not exist: {path}")
        for db_path in self.db_files:
            if not Path(db_path).exists():
                raise RuntimeError(f"scene_source=nuplan requested, but nuPlan DB file does not exist: {db_path}")
        # Fail before scenario iteration with an actionable map-package error.
        # GPKGMapsDB always reads <map_version>.json from map_root, and each
        # manifest entry resolves to <location>/<version>/map.gpkg.
        map_root = Path(str(self.map_root))
        manifest_path = map_root / f"{self.map_version}.json"
        if not manifest_path.exists():
            raise RuntimeError(
                f"nuPlan maps package is incomplete: missing {manifest_path}. "
                f"Expected <map_root>/{self.map_version}.json plus <map_root>/<location>/<version>/map.gpkg; "
                "do not nest the location folders under a nuplan-maps-v1.0/ directory."
            )
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise RuntimeError(f"nuPlan map manifest is not valid JSON: {manifest_path}: {exc}") from exc
        if not isinstance(manifest, dict) or not manifest:
            raise RuntimeError(f"nuPlan map manifest is empty or malformed: {manifest_path}")
        missing_maps: List[str] = []
        for location, meta in manifest.items():
            if not isinstance(meta, dict) or not meta.get("version"):
                continue
            expected = map_root / str(location) / str(meta["version"]) / "map.gpkg"
            if not expected.exists():
                missing_maps.append(str(expected))
        if missing_maps:
            preview = ", ".join(missing_maps[:4])
            raise RuntimeError(
                f"nuPlan maps package does not match its manifest; missing map.gpkg files: {preview}. "
                "Re-extract the official nuPlan maps archive directly into --nuplan_map_root."
            )
        try:
            from nuplan.planning.scenario_builder.nuplan_db.nuplan_scenario_builder import NuPlanScenarioBuilder  # type: ignore
        except Exception as e:  # pragma: no cover - depends on local devkit
            raise RuntimeError(f"nuPlan devkit import failed: {e}") from e
        try:  # pragma: no cover - depends on local devkit
            self._builder = NuPlanScenarioBuilder(
                data_root=self.data_root,
                map_root=self.map_root,
                sensor_root=self.sensor_root,
                db_files=self.db_files,
                map_version=self.map_version,
            )
        except TypeError:  # older devkit signature
            self._builder = NuPlanScenarioBuilder(self.data_root, self.map_root, self.sensor_root, self.db_files, self.map_version)
        except Exception as e:
            raise RuntimeError(f"failed to initialize NuPlanScenarioBuilder: {e}") from e

    def iter_scenarios(
        self,
        max_scenarios: int = 4,
        *,
        skip_scenarios: int = 0,
        expected_last_skipped_episode_id: str | None = None,
    ) -> Iterable[NuPlanScenarioRecord]:
        """Iterate scenarios with an exact prefix-skip hook for crash-safe resume.

        ``skip_scenarios`` is applied *after* nuPlan's deterministic ScenarioFilter
        output is constructed and *before* the expensive per-scenario history/map
        extraction.  This is intentionally not a data sampling mechanism.  It is
        only used to resume a previously committed JSONL prefix whose input
        fingerprint is identical.  ``expected_last_skipped_episode_id`` guards
        against any ordering/input drift before work is skipped.
        """
        skip_scenarios = max(0, int(skip_scenarios))
        if self.scene_source == "synthetic":
            if max_scenarios <= 0:
                raise ValueError("synthetic scene generation requires max_scenarios > 0")
            for idx, rec in enumerate(self._iter_synthetic(max_scenarios)):
                if idx < skip_scenarios:
                    if idx == skip_scenarios - 1 and expected_last_skipped_episode_id and rec.episode.episode_id != expected_last_skipped_episode_id:
                        raise RuntimeError(
                            "resume boundary mismatch for synthetic scenarios: "
                            f"expected {expected_last_skipped_episode_id}, got {rec.episode.episode_id}"
                        )
                    continue
                yield rec
            return
        yield from self._iter_real_nuplan(
            max_scenarios,
            skip_scenarios=skip_scenarios,
            expected_last_skipped_episode_id=expected_last_skipped_episode_id,
        )

    def iter_scenario_index(self, max_scenarios: int = 0) -> Iterable[Dict[str, Any]]:
        """Yield a lightweight identity index without loading 20-step histories.

        This retains the exact nuPlan ScenarioFilter population/order used by the
        heavy extractor, but only records stable identifiers and initial timestamp.
        It is useful for a full immutable candidate inventory while materializing
        expensive passenger-service evidence only for a paper-scale scene subset.
        """
        if self.scene_source != "nuplan":
            raise RuntimeError("scenario indexing is only defined for scene_source=nuplan")
        for idx, scenario in enumerate(self._get_real_nuplan_scenarios(max_scenarios)):
            token, log_name, scenario_type, map_name = self._scenario_identity(scenario, idx)
            ts = safe_call(scenario, ["_initial_lidar_timestamp", "initial_lidar_timestamp"], None)
            try:
                ts_us = int(ts) if ts is not None else None
            except Exception:
                ts_us = None
            yield {
                "index": idx,
                "episode_id": self._episode_id(log_name, token),
                "scenario_token": token,
                "log_name": log_name,
                "scenario_type": scenario_type,
                "map_name": map_name,
                "initial_lidar_timestamp_us": ts_us,
                "split": self.split,
            }

    def _iter_synthetic(self, max_scenarios: int) -> Iterator[NuPlanScenarioRecord]:
        for i in range(max_scenarios):
            eid = f"synthetic_{i:04d}"
            route_length = 1800.0 + 140.0 * i
            initial = Pose2D(0.0, 0.0, 0.0, "local")
            goal = Pose2D(route_length, 0.0, 0.0, "local")
            scene = SceneRecord(
                episode_id=eid,
                source="synthetic",
                split=self.split,
                scenario_token=f"synthetic_token_{i:04d}",
                log_name=f"synthetic_log_{self.split}",
                scenario_type="synthetic_smoke",
                map_name="synthetic_local_map",
                map_version="v0",
                initial_ego_pose=initial,
                mission_goal=goal,
                route_roadblock_ids=[f"rb_{j}" for j in range(4)],
                ego_history=[{"t": float(t), "x": 2.0 * t, "y": 0.0, "v": 2.0, "a": 0.0} for t in range(6)],
                agent_history=[{"t": float(t), "objects": [{"id": "agent0", "type": "vehicle", "x": 20.0 + t, "y": 4.0, "v": 1.0}]} for t in range(6)],
                traffic_light_history=[{"t": float(t), "statuses": []} for t in range(6)],
                route_corridor={"length_m": route_length, "polyline": [[0.0, 0.0], [route_length, 0.0]], "drivable_polygon": [[-5, -10], [route_length + 5, -10], [route_length + 5, 10], [-5, 10]]},
                timestamps_s=[float(t) for t in range(6)],
                metadata={"source": "synthetic", "seed": self.seed + i, "vehicle_safe": True},
            )
            ep = EpisodeMetadata(
                episode_id=eid,
                scenario_id=f"synthetic_scenario_{i:04d}",
                split=self.split,
                origin_anchor="origin",
                destination_anchor="destination",
                request_time_s=1000.0 + 60.0 * i,
                route_length_m=route_length,
                shortest_route_length_m=route_length * 0.92,
                seed=self.seed + i,
                nuplan_available=False,
                scene_source="synthetic",
                map_name=scene.map_name,
                map_version=scene.map_version,
                scenario_token=scene.scenario_token,
                log_name=scene.log_name,
                route_roadblock_ids=scene.route_roadblock_ids,
                metadata={"source": "synthetic", "route_corridor": scene.route_corridor, "vehicle_safe": True},
            )
            yield NuPlanScenarioRecord(ep, scene, scene.ego_history, scene.agent_history, {"map_name": scene.map_name, "map_version": scene.map_version}, scene.route_corridor)

    def _scenario_filter(self, max_scenarios: int):  # pragma: no cover - requires nuPlan installation/data
        scenario_limit = None if max_scenarios <= 0 else int(max_scenarios)
        try:
            from nuplan.planning.scenario_builder.scenario_filter import ScenarioFilter  # type: ignore
        except Exception as e:
            raise RuntimeError(f"failed to import nuPlan ScenarioFilter: {e}") from e
        try:
            return ScenarioFilter(
                scenario_types=self.scenario_types or None,
                scenario_tokens=None,
                log_names=self.log_names or None,
                map_names=self.map_names or None,
                num_scenarios_per_type=None,
                limit_total_scenarios=scenario_limit,
                timestamp_threshold_s=self.timestamp_threshold_s,
                ego_displacement_minimum_m=self.ego_displacement_minimum_m,
                expand_scenarios=False,
                remove_invalid_goals=True,
                shuffle=False,
            )
        except TypeError:
            # Older devkit signature.  These versions expose the original 11
            # fields only; keep the exact legacy behavior when optional filters
            # are unset, and fail rather than silently ignore requested filters.
            if self.timestamp_threshold_s is not None or self.ego_displacement_minimum_m is not None:
                raise RuntimeError(
                    "installed nuPlan ScenarioFilter does not support timestamp/displacement filters; "
                    "upgrade the devkit or leave these options unset"
                )
            return ScenarioFilter(
                self.scenario_types or None, None, self.log_names or None,
                self.map_names or None, None, scenario_limit, None, None,
                False, True, False,
            )

    def _get_real_nuplan_scenarios(self, max_scenarios: int):  # pragma: no cover
        assert self._builder is not None
        scenario_filter = self._scenario_filter(max_scenarios)
        scenarios = None
        for method in ["get_scenarios", "get_scenario_tokens"]:
            if hasattr(self._builder, method):
                try:
                    scenarios = getattr(self._builder, method)(scenario_filter, self._worker)
                    break
                except TypeError:
                    try:
                        scenarios = getattr(self._builder, method)(scenario_filter)
                        break
                    except Exception:
                        continue
        if scenarios is None:
            raise RuntimeError("nuPlan scenario builder did not expose a usable get_scenarios API")
        return scenarios

    @staticmethod
    def _episode_id(log_name: str, token: str) -> str:
        stable = hashlib.sha1(f"{log_name}:{token}".encode()).hexdigest()[:12]
        return f"nuplan_{stable}"

    def _scenario_identity(self, scenario: Any, idx: int) -> tuple[str, str, str | None, str | None]:
        token = safe_call(scenario, ["token", "scenario_token", "get_token"], None)
        log_name = safe_call(scenario, ["log_name", "get_log_name"], None)
        scenario_type = safe_call(scenario, ["scenario_type", "get_scenario_type"], None)
        # NuPlanScenario carries _map_name directly.  Reading it avoids eagerly
        # loading the map DB just to validate a resume boundary / write an index.
        map_name = safe_call(scenario, ["_map_name", "map_name", "get_map_name"], None)
        if not map_name:
            map_api = safe_call(scenario, ["map_api", "get_map_api"], None)
            map_name = safe_call(map_api, ["map_name", "get_map_name"], None) if map_api else None
        if not token or not log_name:
            raise RuntimeError(f"nuPlan scenario missing critical identity at index {idx}: token={token}, log={log_name}")
        return str(token), str(log_name), (str(scenario_type) if scenario_type else None), (str(map_name) if map_name else None)

    def _iter_real_nuplan(
        self,
        max_scenarios: int,
        *,
        skip_scenarios: int = 0,
        expected_last_skipped_episode_id: str | None = None,
    ) -> Iterator[NuPlanScenarioRecord]:  # pragma: no cover - requires nuPlan installation/data
        scenario_limit = None if max_scenarios <= 0 else int(max_scenarios)
        scenarios = self._get_real_nuplan_scenarios(max_scenarios)
        # Do not materialize/copy the complete scenario iterable here.  More
        # importantly, crash-resume skips the already committed prefix before
        # touching history/agents/traffic lights/map geometry.
        for idx, scenario in enumerate(scenarios):
            if scenario_limit is not None and idx >= scenario_limit:
                break
            if idx < skip_scenarios:
                if idx == skip_scenarios - 1 and expected_last_skipped_episode_id:
                    token, log_name, _, _ = self._scenario_identity(scenario, idx)
                    actual = self._episode_id(log_name, token)
                    if actual != expected_last_skipped_episode_id:
                        raise RuntimeError(
                            "resume boundary mismatch: the filtered nuPlan scenario order changed. "
                            f"expected last committed {expected_last_skipped_episode_id}, got {actual}; "
                            "refusing to append to the existing partial files"
                        )
                continue
            yield self._extract_real_scenario(scenario, idx)

    def _extract_real_scenario(self, scenario: Any, idx: int) -> NuPlanScenarioRecord:  # pragma: no cover - requires nuPlan installation/data
        token = safe_call(scenario, ["token", "scenario_token", "get_token"], None)
        log_name = safe_call(scenario, ["log_name", "get_log_name"], None)
        scenario_type = safe_call(scenario, ["scenario_type", "get_scenario_type"], None)
        map_api = safe_call(scenario, ["map_api", "get_map_api"], None)
        map_name = safe_call(map_api, ["map_name", "get_map_name"], None) if map_api else None
        route_ids = safe_call(scenario, ["get_route_roadblock_ids", "route_roadblock_ids"], None)
        if not route_ids:
            raise RuntimeError(f"nuPlan scenario {token or idx} is missing route roadblock IDs")
        ego0 = safe_call(scenario, ["get_ego_state_at_iteration"], None)
        if callable(getattr(scenario, "get_ego_state_at_iteration", None)):
            ego0 = scenario.get_ego_state_at_iteration(0)
        pose0 = self._pose_from_ego(ego0)
        mission_goal_obj = safe_call(scenario, ["get_mission_goal", "mission_goal"], None)
        mission_goal = self._pose_from_any(mission_goal_obj) if mission_goal_obj is not None else None
        iterations = int(safe_call(scenario, ["get_number_of_iterations", "number_of_iterations"], 20) or 20)
        sample_iters = list(range(0, max(iterations, 1), max(1, iterations // 20)))[:20]
        ego_hist = []
        agents = []
        tls = []
        times = []
        for it in sample_iters:
            ego = scenario.get_ego_state_at_iteration(it) if hasattr(scenario, "get_ego_state_at_iteration") else None
            pose = self._pose_from_ego(ego)
            t_s = float(safe_call(ego, ["time_seconds"], it) or it)
            times.append(t_s)
            ego_hist.append({"iteration": it, "t": t_s, "x": pose.x, "y": pose.y, "heading": pose.heading, "v": self._ego_velocity(ego), "a": self._ego_accel(ego)})
            tracked = safe_call(scenario, ["get_tracked_objects_at_iteration"], None)
            try:
                tracked = scenario.get_tracked_objects_at_iteration(it)
            except Exception:
                tracked = None
            agents.append({"iteration": it, "objects": self._tracked_to_records(tracked)})
            try:
                tl = scenario.get_traffic_light_status_at_iteration(it)
            except Exception:
                tl = []
            tls.append({"iteration": it, "statuses": [str(x) for x in (tl or [])]})
        route_polyline = self._extract_route_polyline(route_ids, map_api, pose0, mission_goal)
        route_len = self._estimate_route_length(route_ids, map_api, route_polyline)
        eid = self._episode_id(str(log_name), str(token))
        if not map_name or not token or not log_name:
            raise RuntimeError(f"nuPlan scenario missing critical identifiers: token={token}, log={log_name}, map={map_name}")
        scene = SceneRecord(
            episode_id=eid,
            source="nuplan",
            split=self.split,
            scenario_token=str(token),
            log_name=str(log_name),
            scenario_type=str(scenario_type) if scenario_type else None,
            map_name=str(map_name),
            map_version=self.map_version,
            initial_ego_pose=pose0,
            mission_goal=mission_goal,
            route_roadblock_ids=list(route_ids),
            ego_history=ego_hist,
            agent_history=agents,
            traffic_light_history=tls,
            route_corridor={"roadblock_ids": list(route_ids), "length_m": route_len, "polyline": route_polyline, "polyline_source": "nuplan_map_api_baseline" if len(route_polyline) > 2 else "ego_to_mission_goal_fallback"},
            timestamps_s=times,
            # Never duplicate the complete split DB-path list into every scene.
            # The expanded list is already recorded once in the extraction
            # manifest.  Repeating thousands of paths per episode made full
            # builds needlessly large and expensive to serialize/read.
            metadata={
                "source": "nuplan",
                "data_root": self.data_root,
                "db_files_count": len(self.db_files) if isinstance(self.db_files, list) else None,
            },
        )
        ep = EpisodeMetadata(eid, str(token), self.split, "origin", "destination", times[0] if times else 0.0, route_len, max(route_len * 0.9, 1.0), self.seed + idx, True, "nuplan", str(map_name), self.map_version, str(token), str(log_name), list(route_ids), {"source": "nuplan", "route_corridor": scene.route_corridor})
        # Keep the map API only in the in-memory record.  The serializable SceneRecord
        # above intentionally stores only map identifiers and route metadata.
        return NuPlanScenarioRecord(ep, scene, ego_hist, agents, {"map_name": map_name, "map_version": self.map_version, "map_api": map_api}, scene.route_corridor)

    @staticmethod
    def _pose_from_any(obj: Any) -> Pose2D:
        if obj is None:
            return Pose2D(0.0, 0.0)
        for attr in ["rear_axle", "center", "point"]:
            if hasattr(obj, attr):
                obj = getattr(obj, attr)
                break
        x = float(safe_call(obj, ["x"], 0.0) or 0.0)
        y = float(safe_call(obj, ["y"], 0.0) or 0.0)
        heading = float(safe_call(obj, ["heading"], 0.0) or 0.0)
        return Pose2D(x, y, heading, "map")

    @staticmethod
    def _pose_from_ego(ego: Any) -> Pose2D:
        if ego is None:
            return Pose2D(0.0, 0.0, 0.0, "map")
        axle = safe_call(ego, ["rear_axle", "center"], ego)
        return NuPlanAdapter._pose_from_any(axle)

    @staticmethod
    def _ego_velocity(ego: Any) -> float:
        dyn = safe_call(ego, ["dynamic_car_state"], None)
        speed = safe_call(dyn, ["speed"], None) if dyn else None
        if speed is not None:
            return float(speed)
        return float(safe_call(ego, ["speed"], 0.0) or 0.0)

    @staticmethod
    def _ego_accel(ego: Any) -> float:
        dyn = safe_call(ego, ["dynamic_car_state"], None)
        acc = safe_call(dyn, ["acceleration"], None) if dyn else None
        try:
            return float(acc)
        except Exception:
            return 0.0

    @staticmethod
    def _tracked_to_records(tracked: Any) -> List[Dict[str, Any]]:
        objs = []
        raw = safe_call(tracked, ["tracked_objects", "get_tracked_objects"], []) if tracked is not None else []
        for o in raw or []:
            pose = NuPlanAdapter._pose_from_any(safe_call(o, ["center", "box"], o))
            objs.append({"type": str(safe_call(o, ["tracked_object_type"], "unknown")), "x": pose.x, "y": pose.y, "heading": pose.heading})
        return objs

    @staticmethod
    def _xy_from_any_point(obj: Any) -> tuple[float, float] | None:
        if obj is None:
            return None
        for attr in ["point", "center", "rear_axle"]:
            if hasattr(obj, attr):
                obj = getattr(obj, attr)
                break
        x = safe_call(obj, ["x"], None)
        y = safe_call(obj, ["y"], None)
        if x is None or y is None:
            return None
        try:
            return float(x), float(y)
        except Exception:
            return None

    @staticmethod
    def _points_from_baseline_path(path: Any) -> List[List[float]]:
        if path is None:
            return []
        raw = safe_call(path, ["discrete_path", "get_discrete_path", "points"], None)
        if callable(raw):
            try:
                raw = raw()
            except Exception:
                raw = None
        pts: List[List[float]] = []
        for p in raw or []:
            xy = NuPlanAdapter._xy_from_any_point(p)
            if xy is not None:
                pts.append([xy[0], xy[1]])
        if not pts:
            # Some devkit objects expose a linestring-like geometry.
            geom = safe_call(path, ["linestring", "geometry"], None)
            coords = safe_call(geom, ["coords"], None)
            for p in coords or []:
                try:
                    pts.append([float(p[0]), float(p[1])])
                except Exception:
                    continue
        return pts

    @staticmethod
    def _map_object_candidates(map_api: Any, object_id: str) -> List[Any]:
        if map_api is None:
            return []
        layer_candidates: List[Any] = [None]
        try:
            from nuplan.common.maps.maps_datatypes import SemanticMapLayer  # type: ignore
            for name in ["ROADBLOCK", "ROADBLOCK_CONNECTOR", "LANE", "LANE_CONNECTOR"]:
                if hasattr(SemanticMapLayer, name):
                    layer_candidates.append(getattr(SemanticMapLayer, name))
        except Exception:
            pass
        out: List[Any] = []
        for layer in layer_candidates:
            try:
                obj = map_api.get_map_object(object_id, layer)
            except Exception:
                try:
                    obj = map_api.get_map_object(object_id)
                except Exception:
                    obj = None
            if obj is not None and obj not in out:
                out.append(obj)
        return out

    @staticmethod
    def _points_from_map_object(obj: Any) -> List[List[float]]:
        pts: List[List[float]] = []
        # Roadblocks usually contain interior lanes; lane objects usually contain a baseline path.
        children = []
        for name in ["interior_edges", "interior_edge_ids", "lanes", "lane_connectors"]:
            val = safe_call(obj, [name], None)
            if callable(val):
                try:
                    val = val()
                except Exception:
                    val = None
            if val:
                children.extend(list(val))
        for child in children:
            bl = safe_call(child, ["baseline_path"], None)
            pts.extend(NuPlanAdapter._points_from_baseline_path(bl))
        if pts:
            return pts
        bl = safe_call(obj, ["baseline_path"], None)
        pts.extend(NuPlanAdapter._points_from_baseline_path(bl))
        if pts:
            return pts
        # Last resort: use polygon exterior/centroid for a coarse but map-derived corridor.
        poly = safe_call(obj, ["polygon", "geometry"], None)
        exterior = safe_call(poly, ["exterior"], None)
        coords = safe_call(exterior, ["coords"], None)
        for p in coords or []:
            try:
                pts.append([float(p[0]), float(p[1])])
            except Exception:
                continue
        if not pts:
            c = NuPlanAdapter._xy_from_any_point(safe_call(poly, ["centroid"], None))
            if c is not None:
                pts.append([c[0], c[1]])
        return pts

    @staticmethod
    def _dedupe_polyline(points: List[List[float]], eps: float = 0.25) -> List[List[float]]:
        out: List[List[float]] = []
        for p in points:
            if not out or math.hypot(float(p[0]) - out[-1][0], float(p[1]) - out[-1][1]) > eps:
                out.append([float(p[0]), float(p[1])])
        return out

    def _route_points_for_id(self, map_api: Any, rid: str) -> List[List[float]]:
        map_name = safe_call(map_api, ["map_name", "get_map_name"], None) if map_api is not None else None
        map_key = str(map_name) if map_name else f"map_api:{id(map_api)}"
        key = (map_key, str(rid))
        cached = self._route_object_points_cache.get(key)
        if cached is not None:
            self._route_geometry_cache_hits += 1
            return [[x, y] for x, y in cached]
        self._route_geometry_cache_misses += 1
        obj_pts: List[List[float]] = []
        for obj in self._map_object_candidates(map_api, str(rid)):
            obj_pts = self._points_from_map_object(obj)
            if len(obj_pts) >= 2:
                break
        frozen = tuple((float(p[0]), float(p[1])) for p in obj_pts if len(p) >= 2)
        self._route_object_points_cache[key] = frozen
        return [[x, y] for x, y in frozen]

    def _extract_route_polyline(self, route_ids: List[str], map_api: Any, pose0: Pose2D, mission_goal: Pose2D | None) -> List[List[float]]:
        pts: List[List[float]] = []
        for rid in route_ids:
            obj_pts = self._route_points_for_id(map_api, str(rid))
            if obj_pts:
                # Keep route order by flipping a new segment if needed.
                if pts and len(obj_pts) >= 2:
                    d0 = math.hypot(obj_pts[0][0] - pts[-1][0], obj_pts[0][1] - pts[-1][1])
                    d1 = math.hypot(obj_pts[-1][0] - pts[-1][0], obj_pts[-1][1] - pts[-1][1])
                    if d1 < d0:
                        obj_pts = list(reversed(obj_pts))
                pts.extend(obj_pts)
        pts = self._dedupe_polyline(pts)
        if len(pts) >= 2:
            return pts
        if mission_goal is not None:
            return [[pose0.x, pose0.y], [mission_goal.x, mission_goal.y]]
        return [[pose0.x, pose0.y]]

    @property
    def route_geometry_cache_stats(self) -> Dict[str, int]:
        return {
            "entries": len(self._route_object_points_cache),
            "hits": int(self._route_geometry_cache_hits),
            "misses": int(self._route_geometry_cache_misses),
        }

    @staticmethod
    def _polyline_length(points: List[List[float]]) -> float:
        return sum(math.hypot(float(b[0])-float(a[0]), float(b[1])-float(a[1])) for a, b in zip(points[:-1], points[1:]))

    @staticmethod
    def _estimate_route_length(route_ids: List[str], map_api: Any, route_polyline: List[List[float]] | None = None) -> float:
        # Prefer real route polyline length; otherwise try baseline path lengths and
        # finally a conservative nonzero roadblock-count fallback.
        poly_len = NuPlanAdapter._polyline_length(route_polyline or [])
        if poly_len > 0:
            return poly_len
        total = 0.0
        if map_api is not None:
            for rid in route_ids:
                for obj in NuPlanAdapter._map_object_candidates(map_api, str(rid)):
                    bl = safe_call(obj, ["baseline_path"], None)
                    length = safe_call(bl, ["length"], None)
                    if length:
                        total += float(length)
                        break
        return total if total > 0 else max(100.0, 120.0 * len(route_ids))
