"""Passenger-service transition generation."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Tuple

from capplan.data.accessibility_layer import (
    NoAccessiblePathError,
    _adjacency,
    shortest_accessible_path_stats,
    shortest_accessible_path_stats_from_tree,
    shortest_path_tree,
)
from capplan.data.schemas import AccessibilityGraph, CandidateTransition, PUDOAnchor, ResourceEvidence, TransitionTests, VehicleInterface


@dataclass
class TransitionGeneratorConfig:
    include_replan: bool = True
    max_pudo: int = 4
    deterministic_wait_s: float = 120.0
    default_speed_mps: float = 8.0
    min_dynamic_availability: float = 0.05
    # Keep the graph compact, but choose the capped candidates by actual service
    # topology rather than lexicographic PUDO id order.  The previous first-N
    # truncation was arbitrary because hybrid PUDO rows are emitted sorted by
    # anchor id, not by entrance proximity.
    route_aware_pudo_selection: bool = True


class TransitionGenerator:
    def __init__(self, config: TransitionGeneratorConfig | None = None) -> None:
        self.config = config or TransitionGeneratorConfig()

    def generate(
        self,
        episode_id: str,
        graph: AccessibilityGraph,
        pudo_anchors: List[PUDOAnchor],
        vehicle: VehicleInterface,
        origin_anchor: str = "origin",
        destination_anchor: str = "destination",
        scene_context: Dict[str, Any] | None = None,
    ) -> List[CandidateTransition]:
        scene_context = scene_context or {}
        pickup_pool = [p for p in pudo_anchors if p.kind in ("pickup", "pickup_dropoff")]
        dropoff_pool = [p for p in pudo_anchors if p.kind in ("dropoff", "pickup_dropoff")]
        if not pickup_pool:
            pickup_pool = list(pudo_anchors)
        if not dropoff_pool:
            dropoff_pool = list(pudo_anchors)
        out: List[CandidateTransition] = []

        # A real-city graph can contain tens of thousands of pedestrian edges.
        # Build one adjacency and two exact single-source shortest-path trees:
        # origin -> all nodes and destination -> all nodes.  Every pickup/access
        # and dropoff/egress path can then be reconstructed exactly without
        # running 4+4 independent Dijkstras per episode.
        adjacency = _adjacency(graph)
        graph_node_ids = {n.node_id for n in graph.nodes}
        node_kinds = {n.node_id: n.kind for n in graph.nodes}
        origin_tree = self._safe_path_tree(graph, origin_anchor, adjacency, graph_node_ids)
        destination_tree = self._safe_path_tree(graph, destination_anchor, adjacency, graph_node_ids)

        if self.config.route_aware_pudo_selection:
            pickups = self._select_pudo_candidates(pickup_pool, origin_tree[0] if origin_tree else {}, self.config.max_pudo)
            dropoffs = self._select_pudo_candidates(dropoff_pool, destination_tree[0] if destination_tree else {}, self.config.max_pudo)
        else:
            pickups = pickup_pool[: self.config.max_pudo]
            dropoffs = dropoff_pool[: self.config.max_pudo]

        path_cache: Dict[Tuple[str, str], Dict[str, Any] | NoAccessiblePathError] = {}

        for pu in pickups:
            out.append(self._access_transition(
                episode_id, graph, origin_anchor, pu, scene_context,
                adjacency, graph_node_ids, node_kinds, path_cache, origin_tree,
            ))
            out.append(self._wait_transition(episode_id, pu, vehicle, scene_context))
            out.append(self._board_transition(episode_id, pu, vehicle))

        for pu in pickups:
            for do in dropoffs:
                if pu.anchor_id == do.anchor_id and len(dropoffs) > 1:
                    continue
                out.append(self._ride_transition(episode_id, pu, do, vehicle, scene_context))

        # All rides that end at the same drop-off converge to the same
        # ``veh:*:alight:<dropoff>`` state.  Alight/egress/destination evidence
        # depends only on the drop-off, destination and vehicle, not on which
        # pickup produced the ride.  Emitting one copy per pickup created exact
        # duplicate state transitions (12 alight + 12 egress + 12 destination
        # edges with the default 4x4 candidate grid).  Generate each suffix edge
        # once per drop-off; the typed ledger still carries pickup-specific ride
        # history into the shared state.
        for do in dropoffs:
            out.append(self._alight_transition(episode_id, do, vehicle))
            out.append(self._egress_transition(
                episode_id, graph, do, destination_anchor,
                scene_context, adjacency, graph_node_ids, node_kinds,
                path_cache, destination_tree,
            ))
            out.append(self._destination_transition(episode_id, do, destination_anchor))

        if self.config.include_replan:
            out.extend(self._replan_transitions(episode_id, pickups, dropoffs))
        return out

    @staticmethod
    def _safe_path_tree(graph, root: str, adjacency, graph_node_ids):
        try:
            return shortest_path_tree(
                graph, root, adjacency=adjacency, node_ids=graph_node_ids
            )
        except NoAccessiblePathError:
            return None

    @staticmethod
    def _select_pudo_candidates(
        candidates: List[PUDOAnchor],
        distances: Dict[str, float],
        limit: int,
    ) -> List[PUDOAnchor]:
        """Choose a deterministic, topology-aware compact PUDO candidate set.

        Candidate generation in the paper is explicitly conditioned on entrance
        distance and stopping feasibility.  Hybrid evidence JSONL is sorted by
        anchor id for reproducibility, so ``rows[:4]`` is not a meaningful
        service policy and can accidentally choose four distant/unreachable
        curbs while closer legal anchors exist.

        We therefore rank by exact pedestrian shortest-path distance.  Legal,
        currently unblocked, graph-connected anchors are preferred; the final
        slot may retain a connected challenge candidate so transition-level
        negatives are not artificially removed.  The rule is passenger-agnostic
        and deterministic, preserving same-scene capability counterfactuals.
        """
        if limit <= 0 or not candidates:
            return []

        def node_id(p: PUDOAnchor) -> str:
            return str(p.adjacent_ped_node_id or p.anchor_id)

        def distance(p: PUDOAnchor) -> float:
            return float(distances.get(node_id(p), float("inf")))

        def rank(p: PUDOAnchor) -> tuple[float, float, str]:
            # Higher confidence wins only as a deterministic tie breaker after
            # service distance; it must not replace topological accessibility.
            return (distance(p), -float(min(p.map_confidence, p.dynamic_confidence)), p.anchor_id)

        connected = [p for p in candidates if math.isfinite(distance(p))]
        viable = [p for p in connected if bool(p.legal_stop) and float(p.blockage_risk) < 0.85]
        viable.sort(key=rank)
        connected.sort(key=rank)
        disconnected = sorted((p for p in candidates if not math.isfinite(distance(p))), key=lambda p: p.anchor_id)

        # Preserve one slot for an informative challenge when such a candidate
        # exists.  With the default limit=4 this gives up to three plausible
        # service anchors plus one negative/harder anchor.
        preferred_slots = limit if len(connected) <= limit else max(2, limit - 1)
        selected: List[PUDOAnchor] = viable[:preferred_slots]
        selected_ids = {p.anchor_id for p in selected}
        for p in connected + disconnected:
            if len(selected) >= limit:
                break
            if p.anchor_id in selected_ids:
                continue
            selected.append(p)
            selected_ids.add(p.anchor_id)
        return selected

    def _access_transition(
        self, episode_id: str, graph: AccessibilityGraph, origin_anchor: str,
        pu: PUDOAnchor, scene_context: Dict[str, Any], adjacency, graph_node_ids, node_kinds,
        path_cache: Dict[Tuple[str, str], Dict[str, Any] | NoAccessiblePathError],
        origin_tree,
    ) -> CandidateTransition:
        start = origin_anchor
        end = pu.adjacent_ped_node_id or pu.anchor_id
        try:
            cached = path_cache.get((start, end))
            if isinstance(cached, NoAccessiblePathError):
                raise cached
            if cached is None:
                if origin_tree is not None:
                    cached = shortest_accessible_path_stats_from_tree(
                        graph, start, end, origin_tree[0], origin_tree[1], node_kinds=node_kinds
                    )
                else:
                    cached = shortest_accessible_path_stats(
                        graph, start, end, adjacency=adjacency, node_ids=graph_node_ids,
                        node_kinds=node_kinds,
                    )
                path_cache[(start, end)] = cached
            path = cached
            tests = TransitionTests(True, True, True, True, True, not path.get("obstacle", False), ["obstacle_on_path"] if path.get("obstacle") else [])
        except NoAccessiblePathError as e:
            path_cache[(start, end)] = e
            path = {"distance": None, "width": None, "slope": None, "cross_slope": None, "curb_ramp": None, "step_free": None, "surface": None, "obstacle": False, "blockage_risk": 1.0, "confidence": 0.0, "missing_fields": ["path"], "lighting": None, "shelter": None, "path_edge_ids": []}
            tests = TransitionTests(True, False, False, False, True, False, [str(e)])
        evidence = self._path_evidence("access", path, scene_context)
        return self._make_transition(
            episode_id,
            f"{episode_id}:access:{origin_anchor}->{pu.anchor_id}",
            origin_anchor,
            pu.anchor_id,
            "origin",
            "access",
            "access",
            evidence,
            availability=0.0 if not tests.dynamically_available else 1.0,
            map_confidence=path.get("confidence", 0.0) or 0.0,
            tests=tests,
            cost=float(path.get("distance") or 1e6),
            completion_value=0.75,
            metadata={"path_edge_ids": path.get("path_edge_ids", []), "adjacent_ped_node_id": end},
        )

    def _wait_transition(self, episode_id: str, pu: PUDOAnchor, vehicle: VehicleInterface, scene_context: Dict[str, Any]) -> CandidateTransition:
        blocked = pu.blockage_risk >= 0.85
        evidence = [
            ResourceEvidence("wait_exposure_s", "cumulative", self.config.deterministic_wait_s, sigma=20.0, confidence=pu.dynamic_confidence, source="service_trace"),
            ResourceEvidence("identification_modality", "categorical", list(vehicle.notification_modes), confidence=1.0, source="vehicle_spec"),
            ResourceEvidence("lighting", "categorical", self._resolve_lighting(pu.lighting, scene_context), confidence=pu.map_confidence, source="curbside_map+scene_time", missing=pu.lighting is None),
            ResourceEvidence("shelter", "categorical", pu.shelter, confidence=pu.map_confidence, source="curbside_map", missing=pu.shelter is None),
            ResourceEvidence("map_confidence", "lower", pu.map_confidence, sigma=0.02, confidence=pu.map_confidence, source="curbside_map"),
            ResourceEvidence("dynamic_confidence", "lower", pu.dynamic_confidence, sigma=0.02, confidence=pu.dynamic_confidence, source="perception"),
            ResourceEvidence("blockage_risk", "probabilistic", pu.blockage_risk, sigma=0.03, confidence=pu.dynamic_confidence, source="prediction"),
        ]
        tests = TransitionTests(True, bool(pu.adjacent_ped_node_id), True, True, True, not blocked, ["dynamic_blockage_risk_high"] if blocked else [])
        return self._make_transition(episode_id, f"{episode_id}:wait:{pu.anchor_id}", pu.anchor_id, pu.anchor_id, "access", "wait", "wait", evidence, availability=max(0.0, 1.0 - pu.blockage_risk), map_confidence=pu.map_confidence, tests=tests, cost=self.config.deterministic_wait_s / 10.0, completion_value=0.80)

    def _board_transition(self, episode_id: str, pu: PUDOAnchor, vehicle: VehicleInterface) -> CandidateTransition:
        interface_valid, reasons = self._interface_valid(pu, vehicle)
        evidence = self._interface_evidence(pu, vehicle, "board")
        tests = TransitionTests(True, bool(pu.adjacent_ped_node_id), True, bool(pu.legal_stop), interface_valid, pu.blockage_risk < 0.85, reasons + ([] if pu.legal_stop else ["illegal_stop"]))
        return self._make_transition(
            episode_id,
            f"{episode_id}:board:{pu.anchor_id}:{vehicle.vehicle_id}",
            pu.anchor_id,
            f"veh:{vehicle.vehicle_id}:board:{pu.anchor_id}",
            "wait",
            "board",
            "board",
            evidence,
            availability=max(0.0, 1.0 - pu.blockage_risk),
            map_confidence=pu.map_confidence,
            interface={"vehicle_id": vehicle.vehicle_id, "door_side": vehicle.door_side, "boarding_sides": vehicle.boarding_sides, "anchor_side": pu.side, "legal_stop": pu.legal_stop},
            dynamic={"blocked": pu.blockage_risk >= 0.85},
            tests=tests,
            cost=vehicle.dwell_time_s / 10.0,
            completion_value=0.85,
        )

    def _ride_transition(self, episode_id: str, pu: PUDOAnchor, do: PUDOAnchor, vehicle: VehicleInterface, scene_context: Dict[str, Any]) -> CandidateTransition:
        route_length = float(scene_context.get("route_length_m") or scene_context.get("route_corridor", {}).get("length_m") or 1800.0)
        route_factor = 1.0 + 0.03 * abs(_pudo_index(pu.anchor_id) - _pudo_index(do.anchor_id))
        ride_time = route_length * route_factor / max(1.0, self.config.default_speed_mps)
        peak_accel = float(scene_context.get("peak_accel_mps2", 1.25 + 0.06 * _pudo_index(pu.anchor_id)))
        peak_jerk = float(scene_context.get("peak_jerk_mps3", 1.8 + 0.08 * _pudo_index(do.anchor_id)))
        motion = float(scene_context.get("motion_exposure", max(0.8, route_length / 2000.0) + 0.1 * abs(_pudo_index(pu.anchor_id) - _pudo_index(do.anchor_id))))
        traffic_risk = float(scene_context.get("availability_risk", 0.04))
        motion_source = str(scene_context.get("ride_motion_evidence_source") or "trajectory_heuristic")
        evidence = [
            ResourceEvidence("ride_time_s", "cumulative", ride_time, sigma=max(10.0, 0.05 * ride_time), confidence=0.93, source="route_corridor"),
            ResourceEvidence("motion_exposure", "cumulative", motion, sigma=0.15, confidence=0.90, source=motion_source),
            ResourceEvidence("peak_accel_mps2", "upper", peak_accel, sigma=0.12, confidence=0.90, source=motion_source),
            ResourceEvidence("peak_jerk_mps3", "upper", peak_jerk, sigma=0.18, confidence=0.90, source=motion_source),
            ResourceEvidence("availability_risk", "probabilistic", traffic_risk, sigma=0.02, confidence=0.90, source="prediction"),
        ]
        tests = TransitionTests(True, True, True, True, True, traffic_risk < 0.85, ["traffic_unavailable"] if traffic_risk >= 0.85 else [])
        return self._make_transition(
            episode_id,
            f"{episode_id}:ride:{pu.anchor_id}->{do.anchor_id}:route0:{vehicle.vehicle_id}",
            f"veh:{vehicle.vehicle_id}:board:{pu.anchor_id}",
            f"veh:{vehicle.vehicle_id}:alight:{do.anchor_id}",
            "board",
            "ride",
            "ride",
            evidence,
            availability=max(0.0, 1.0 - traffic_risk),
            map_confidence=0.93,
            tests=tests,
            cost=ride_time / 20.0,
            completion_value=0.90,
            metadata={"route_length_m": route_length, "pickup_anchor": pu.anchor_id, "dropoff_anchor": do.anchor_id},
        )

    def _alight_transition(self, episode_id: str, do: PUDOAnchor, vehicle: VehicleInterface) -> CandidateTransition:
        interface_valid, reasons = self._interface_valid(do, vehicle)
        evidence = self._interface_evidence(do, vehicle, "alight")
        tests = TransitionTests(True, bool(do.adjacent_ped_node_id), True, bool(do.legal_stop), interface_valid, do.blockage_risk < 0.85, reasons + ([] if do.legal_stop else ["illegal_stop"]))
        return self._make_transition(
            episode_id,
            f"{episode_id}:alight:{do.anchor_id}:{vehicle.vehicle_id}",
            f"veh:{vehicle.vehicle_id}:alight:{do.anchor_id}",
            do.anchor_id,
            "ride",
            "alight",
            "alight",
            evidence,
            availability=max(0.0, 1.0 - do.blockage_risk),
            map_confidence=do.map_confidence,
            interface={"vehicle_id": vehicle.vehicle_id, "door_side": vehicle.door_side, "boarding_sides": vehicle.boarding_sides, "anchor_side": do.side, "legal_stop": do.legal_stop},
            dynamic={"blocked": do.blockage_risk >= 0.85},
            tests=tests,
            cost=vehicle.dwell_time_s / 10.0,
            completion_value=0.82,
        )

    def _egress_transition(
        self, episode_id: str, graph: AccessibilityGraph, do: PUDOAnchor,
        destination_anchor: str, scene_context: Dict[str, Any],
        adjacency, graph_node_ids, node_kinds,
        path_cache: Dict[Tuple[str, str], Dict[str, Any] | NoAccessiblePathError],
        destination_tree,
    ) -> CandidateTransition:
        start = do.adjacent_ped_node_id or do.anchor_id
        end = destination_anchor
        try:
            cached = path_cache.get((start, end))
            if isinstance(cached, NoAccessiblePathError):
                raise cached
            if cached is None:
                if destination_tree is not None:
                    # The precomputed tree is rooted at destination.  Graph edges
                    # are undirected in the accessibility router, so reconstruct
                    # destination->dropoff and reverse the displayed path.
                    cached = shortest_accessible_path_stats_from_tree(
                        graph, end, start, destination_tree[0], destination_tree[1],
                        node_kinds=node_kinds, reverse_output=True,
                    )
                else:
                    cached = shortest_accessible_path_stats(
                        graph, start, end, adjacency=adjacency, node_ids=graph_node_ids,
                        node_kinds=node_kinds,
                    )
                path_cache[(start, end)] = cached
            path = cached
            tests = TransitionTests(True, True, True, True, True, not path.get("obstacle", False), ["obstacle_on_path"] if path.get("obstacle") else [])
        except NoAccessiblePathError as e:
            path_cache[(start, end)] = e
            path = {"distance": None, "width": None, "slope": None, "cross_slope": None, "curb_ramp": None, "step_free": None, "surface": None, "obstacle": False, "blockage_risk": 1.0, "confidence": 0.0, "missing_fields": ["path"], "lighting": None, "shelter": None, "path_edge_ids": []}
            tests = TransitionTests(True, False, False, False, True, False, [str(e)])
        evidence = self._path_evidence("egress", path, scene_context)
        return self._make_transition(
            episode_id,
            f"{episode_id}:egress:{do.anchor_id}->{destination_anchor}",
            do.anchor_id,
            destination_anchor,
            "alight",
            "egress",
            "egress",
            evidence,
            availability=0.0 if not tests.dynamically_available else 1.0,
            map_confidence=path.get("confidence", 0.0) or 0.0,
            tests=tests,
            cost=float(path.get("distance") or 1e6),
            completion_value=0.90,
            metadata={"path_edge_ids": path.get("path_edge_ids", []), "adjacent_ped_node_id": start},
        )

    def _destination_transition(self, episode_id: str, do: PUDOAnchor, destination_anchor: str) -> CandidateTransition:
        return self._make_transition(
            episode_id,
            f"{episode_id}:destination:{do.anchor_id}",
            destination_anchor,
            destination_anchor,
            "egress",
            "destination",
            "egress",
            [],
            availability=1.0,
            map_confidence=1.0,
            tests=TransitionTests(),
            cost=0.0,
            completion_value=1.0,
        )

    def _replan_transitions(self, episode_id: str, pickups: List[PUDOAnchor], dropoffs: List[PUDOAnchor]) -> List[CandidateTransition]:
        out: List[CandidateTransition] = []
        for anchors, phase in [(pickups, "access"), (pickups, "wait"), (dropoffs, "alight")]:
            for i, a in enumerate(anchors):
                if len(anchors) < 2:
                    continue
                b = anchors[(i + 1) % len(anchors)]
                if a.anchor_id == b.anchor_id:
                    continue
                out.append(self._make_transition(
                    episode_id,
                    f"{episode_id}:replan:{phase}:{a.anchor_id}->{b.anchor_id}",
                    a.anchor_id,
                    b.anchor_id,
                    phase,
                    phase,
                    "replan",
                    [ResourceEvidence("availability_risk", "probabilistic", 0.02, sigma=0.01, confidence=min(a.dynamic_confidence, b.dynamic_confidence), source="planner")],
                    availability=0.9,
                    map_confidence=min(a.map_confidence, b.map_confidence),
                    tests=TransitionTests(True, True, True, True, True, True, []),
                    cost=8.0,
                    completion_value=0.3,
                    metadata={"from_real_anchor": a.anchor_id, "to_real_anchor": b.anchor_id},
                ))
        return out

    def _evidence_or_missing(
        self,
        resource_name: str,
        kind: str,
        value: Any,
        *,
        missing: bool = False,
        reason: str | None = None,
        **kwargs: Any,
    ) -> ResourceEvidence:
        """Create evidence without leaking aggregate values for missing fields.

        A path can be partially observed: for example one edge may have a slope
        value while the connector into a route-derived PUDO has no audited slope.
        In that case the aggregate may be numerically non-null, but the resource
        label must still be marked missing and its supervised value must be
        ``None``. The raw aggregate is retained in ``observed`` for debugging.
        """
        observed_value = kwargs.pop("observed", value)
        if missing or value is None:
            return ResourceEvidence(resource_name, kind, None, observed=observed_value, missing=True, reason=reason or "not_observed", **kwargs)
        return ResourceEvidence(resource_name, kind, value, observed=observed_value, missing=False, **kwargs)

    @staticmethod
    def _resolve_lighting(raw: Any, scene_context: Dict[str, Any]) -> Any:
        """Resolve static lighting infrastructure against the request local time.

        Hybrid overlays store whether the infrastructure is lit, not an
        impossible per-edge time-of-day label.  Daylight automatically satisfies
        lighting requirements; after dark, only lit infrastructure remains lit.
        If local time is unavailable we preserve the raw evidence.
        """
        if raw is None:
            return None
        hour = scene_context.get("request_local_hour")
        try:
            hour = float(hour)
        except (TypeError, ValueError):
            return raw
        if 7.0 <= hour < 19.0:
            return "day"
        norm = str(raw).strip().lower()
        return "lit" if norm in {"lit", "well_lit", "day_or_lit"} else "unlit"

    def _path_evidence(self, phase: str, path: Dict[str, Any], scene_context: Dict[str, Any] | None = None) -> List[ResourceEvidence]:
        scene_context = scene_context or {}
        prefix = "access" if phase == "access" else "egress"
        missing = set(path.get("missing_fields") or [])
        conf = path.get("confidence", 0.0)
        return [
            self._evidence_or_missing(f"{prefix}_distance_m", "cumulative", path.get("distance"), sigma=(path.get("distance") or 0.0) * 0.03, confidence=conf, source="pedestrian_graph", missing=path.get("distance") is None),
            self._evidence_or_missing("slope", "upper", path.get("slope"), sigma=0.005, confidence=conf, source="accessibility_map", missing="slope" in missing or path.get("slope") is None, reason="partial_path_slope_missing" if "slope" in missing else None),
            self._evidence_or_missing("cross_slope", "upper", path.get("cross_slope"), sigma=0.003, confidence=conf, source="accessibility_map", missing="cross_slope" in missing or path.get("cross_slope") is None, reason="partial_path_cross_slope_missing" if "cross_slope" in missing else None),
            self._evidence_or_missing("path_width_m", "lower", path.get("width"), sigma=0.05, confidence=conf, source="accessibility_map", missing="path_width_m" in missing or path.get("width") is None, reason="partial_path_width_missing" if "path_width_m" in missing else None),
            self._evidence_or_missing("curb_ramp", "categorical", path.get("curb_ramp"), confidence=conf, source="accessibility_map", missing="curb_ramp" in missing or path.get("curb_ramp") is None, reason="partial_path_curb_ramp_missing" if "curb_ramp" in missing else None),
            self._evidence_or_missing("step_free", "categorical", path.get("step_free"), confidence=conf, source="accessibility_map", missing="step_free" in missing or path.get("step_free") is None, reason="partial_path_step_free_missing" if "step_free" in missing else None),
            self._evidence_or_missing("surface", "categorical", path.get("surface"), confidence=conf, source="accessibility_map", missing="surface" in missing or path.get("surface") is None, reason="partial_path_surface_missing" if "surface" in missing else None),
            self._evidence_or_missing("lighting", "categorical", self._resolve_lighting(path.get("lighting"), scene_context), confidence=conf, source="accessibility_map+scene_time", missing=path.get("lighting") is None),
            self._evidence_or_missing("map_confidence", "lower", path.get("confidence"), sigma=0.02, confidence=conf, source="accessibility_map", missing=path.get("confidence") is None),
            ResourceEvidence("blockage_risk", "probabilistic", path.get("blockage_risk", 0.02), sigma=0.02, confidence=conf, source="perception"),
        ]

    def _interface_evidence(self, anchor: PUDOAnchor, vehicle: VehicleInterface, phase: str) -> List[ResourceEvidence]:
        # Correct semantics for audited/hybrid rows:
        #   anchor.deployment_clearance_m = AVAILABLE environmental clear space
        #   vehicle.deployment_clearance_m = REQUIRED deployment envelope.
        # Legacy generated anchors used one already-combined scalar; retain that
        # behavior only when explicitly marked legacy_effective_clearance.
        clearance_missing = anchor.deployment_clearance_m is None
        required_clearance = max(0.0, float(vehicle.deployment_clearance_m))
        semantics = str(getattr(anchor, "deployment_clearance_semantics", "legacy_effective_clearance") or "legacy_effective_clearance")
        raw_clearance = None if clearance_missing else float(anchor.deployment_clearance_m)
        if semantics == "available_environment_clear_space":
            evidence_clearance = raw_clearance
            clearance_source = "curbside_map+vehicle_requirement"
        else:
            # Backward-compatible interpretation for historical bootstrap PUDOs.
            evidence_clearance = None if raw_clearance is None else min(raw_clearance, required_clearance)
            clearance_source = "legacy_effective_interface_clearance"

        low_floor_kneeling_missing = anchor.curb_height_m is None
        low_floor_kneeling = None if low_floor_kneeling_missing else bool(vehicle.low_floor and vehicle.kneeling and anchor.curb_height_m <= 0.06)
        side_obs = {"vehicle_side": vehicle.door_side, "curb_side": anchor.side, "observed": anchor.side}
        return [
            ResourceEvidence("door_side", "categorical", side_obs, confidence=min(1.0, anchor.map_confidence), source="vehicle_spec+curbside_map", observed=side_obs, required=None, missing=anchor.side == "unknown"),
            ResourceEvidence("ramp", "categorical", vehicle.ramp, confidence=1.0, source="vehicle_spec"),
            ResourceEvidence("lift", "categorical", vehicle.lift, confidence=1.0, source="vehicle_spec"),
            ResourceEvidence("low_floor", "categorical", vehicle.low_floor, confidence=1.0, source="vehicle_spec"),
            ResourceEvidence("kneeling", "categorical", vehicle.kneeling, confidence=1.0, source="vehicle_spec"),
            self._evidence_or_missing("low_floor_kneeling", "categorical", low_floor_kneeling, confidence=min(1.0, anchor.map_confidence), source="vehicle_spec+curbside_map", missing=low_floor_kneeling_missing, reason="curb_height_missing" if low_floor_kneeling_missing else None),
            ResourceEvidence("door_width_m", "lower", vehicle.door_width_m, sigma=0.01, confidence=1.0, source="vehicle_spec"),
            self._evidence_or_missing("door_side_clearance_m", "lower", evidence_clearance, sigma=0.05, confidence=anchor.map_confidence, source=clearance_source, observed=raw_clearance, required=required_clearance, missing=clearance_missing, reason="deployment_clearance_missing" if clearance_missing else None),
            self._evidence_or_missing("deployment_clearance_m", "lower", evidence_clearance, sigma=0.05, confidence=anchor.map_confidence, source=clearance_source, observed=raw_clearance, required=required_clearance, missing=clearance_missing, reason="deployment_clearance_missing" if clearance_missing else None),
            self._evidence_or_missing("ramp_clearance_m", "lower", evidence_clearance, sigma=0.05, confidence=anchor.map_confidence, source=clearance_source, observed=raw_clearance, required=required_clearance, missing=clearance_missing, reason="deployment_clearance_missing" if clearance_missing else None),
            self._evidence_or_missing("curb_height_m", "upper", anchor.curb_height_m, sigma=0.01, confidence=anchor.map_confidence, source="curbside_map", missing=anchor.curb_height_m is None, reason="curb_height_missing" if anchor.curb_height_m is None else None),
            ResourceEvidence("dwell_time_s", "cumulative", vehicle.dwell_time_s, sigma=5.0, confidence=1.0, source="vehicle_spec"),
            ResourceEvidence("map_confidence", "lower", anchor.map_confidence, sigma=0.02, confidence=anchor.map_confidence, source="curbside_map"),
            ResourceEvidence("blockage_risk", "probabilistic", anchor.blockage_risk, sigma=0.03, confidence=anchor.dynamic_confidence, source="prediction"),
            ResourceEvidence("deployment_risk", "probabilistic", 0.03 if (vehicle.ramp or vehicle.lift or low_floor_kneeling) else 0.15, sigma=0.02, confidence=1.0, source="fleet_audit"),
        ]

    def _interface_valid(self, anchor: PUDOAnchor, vehicle: VehicleInterface) -> tuple[bool, List[str]]:
        reasons: List[str] = []
        if not anchor.legal_stop:
            reasons.append("illegal_stop")
        if anchor.side == "unknown":
            reasons.append("unknown_curb_side")
        if vehicle.door_side != "both" and anchor.side not in (vehicle.door_side, "both"):
            reasons.append("vehicle_door_side_incompatible_with_curb")
        if anchor.deployment_clearance_m is None or anchor.deployment_clearance_m <= 0:
            reasons.append("missing_or_zero_deployment_clearance")
        elif str(getattr(anchor, "deployment_clearance_semantics", "legacy_effective_clearance")) == "available_environment_clear_space":
            if float(anchor.deployment_clearance_m) + 1e-9 < max(0.0, float(vehicle.deployment_clearance_m)):
                reasons.append("insufficient_environment_deployment_clearance")
        if vehicle.door_width_m <= 0:
            reasons.append("invalid_door_width")
        return len(reasons) == 0, reasons

    @staticmethod
    def _make_transition(episode_id: str, tid: str, u: str, v: str, q: str, q2: str, action: str, evidence: List[ResourceEvidence], availability: float = 1.0, map_confidence: float = 1.0, interface: Dict[str, Any] | None = None, dynamic: Dict[str, Any] | None = None, cost: float = 1.0, completion_value: float = 0.5, tests: TransitionTests | None = None, metadata: Dict[str, Any] | None = None) -> CandidateTransition:
        confs = [ev.confidence for ev in evidence if ev.confidence is not None] or [map_confidence]
        tests = tests or TransitionTests()
        if dynamic is None:
            dynamic = {"blocked": not tests.dynamically_available}
        return CandidateTransition(tid, episode_id, u, v, q, q2, action, evidence, max(0.0, min(1.0, float(availability))), min(confs + [map_confidence]), interface or {}, dynamic, float(cost), max(0.0, min(1.0, float(completion_value))), tests, metadata or {})


def _pudo_index(anchor_id: str) -> int:
    try:
        return int(anchor_id.split("_")[-1])
    except Exception:
        return 0
