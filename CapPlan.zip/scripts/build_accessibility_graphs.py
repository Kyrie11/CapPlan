#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import math
import multiprocessing as mp
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from capplan.data.gis_fusion import (
    AccessibilityFusionBuilder,
    GISFeatureSpatialIndex,
    CoordinateTransformer,
    iter_scene_contexts,
    load_gis_features,
    read_scene_contexts,
    scene_context_count,
)
from capplan.data.schemas import AccessibilityEdge, AccessibilityGraph, AccessibilityNode, Pose2D, to_dict
from capplan.utils.serialization import dump_json, read_jsonl, write_jsonl
from capplan.utils.build_fingerprint import fingerprint

GRAPH_BUILD_VERSION = "20260823_dem_evidence_v5"

try:
    from tqdm.auto import tqdm  # type: ignore
except Exception:  # pragma: no cover - tqdm is optional for minimal envs
    def tqdm(iterable=None, **kwargs):  # type: ignore
        return iterable if iterable is not None else []


def _read_json_records(path: str | None) -> List[Dict[str, Any]]:
    if not path:
        return []
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    if p.suffix.lower() == ".json":
        payload = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            for key in ["features", "nodes", "edges", "records"]:
                if isinstance(payload.get(key), list):
                    return [dict(x) for x in payload[key]]
            return [payload]
        return [dict(x) for x in payload]
    return read_jsonl(p)


def _norm_source(row: Dict[str, Any], fallback: str) -> str:
    return str(row.get("source") or row.get("evidence_source") or row.get("data_source") or fallback)


def _node(row: Dict[str, Any], fallback_source: str) -> AccessibilityNode:
    if "node_id" not in row:
        if "id" in row:
            row = {**row, "node_id": row["id"]}
        else:
            raise ValueError(f"accessibility node missing node_id/id: {row}")
    if "x" not in row or "y" not in row:
        coords = row.get("coordinates") or row.get("geometry")
        if isinstance(coords, list) and coords and isinstance(coords[0], (int, float)):
            row = {**row, "x": coords[0], "y": coords[1]}
        else:
            raise ValueError(f"accessibility node missing x/y: {row.get('node_id')}")
    kind = row.get("kind") or row.get("node_type") or "sidewalk_vertex"
    if kind in {"origin_entrance", "destination_entrance"}:
        kind = "entrance"
    return AccessibilityNode(
        node_id=str(row["node_id"]),
        x=float(row["x"]),
        y=float(row["y"]),
        kind=str(kind),
        confidence=float(row.get("confidence", row.get("map_confidence", 1.0))),
        timestamp_s=row.get("timestamp_s"),
        source=_norm_source(row, fallback_source),
        pose=Pose2D(float(row["x"]), float(row["y"]), float(row.get("heading", 0.0)), str(row.get("frame", "map"))),
    )


def _edge(row: Dict[str, Any], fallback_source: str, nodes: Dict[str, AccessibilityNode]) -> AccessibilityEdge:
    if "edge_id" not in row:
        if "id" in row:
            row = {**row, "edge_id": row["id"]}
        elif row.get("from_node") and row.get("to_node"):
            row = {**row, "edge_id": f"{row['from_node']}_to_{row['to_node']}"}
        else:
            raise ValueError(f"accessibility edge missing edge_id/id: {row}")
    frm = str(row.get("from_node") or row.get("u") or row.get("from"))
    to = str(row.get("to_node") or row.get("v") or row.get("to"))
    if frm not in nodes or to not in nodes:
        raise ValueError(f"accessibility edge {row.get('edge_id')} references missing nodes {frm}->{to}")
    geom = row.get("geometry") or [[nodes[frm].x, nodes[frm].y], [nodes[to].x, nodes[to].y]]
    if row.get("length_m") is None:
        length = 0.0
        for a, b in zip(geom[:-1], geom[1:]):
            length += math.hypot(float(b[0]) - float(a[0]), float(b[1]) - float(a[1]))
    else:
        length = float(row["length_m"])
    return AccessibilityEdge(
        edge_id=str(row["edge_id"]),
        from_node=frm,
        to_node=to,
        length_m=max(0.001, float(length)),
        width_m=row.get("width_m", row.get("sidewalk_width_m")),
        slope=row.get("slope", row.get("running_slope")),
        cross_slope=row.get("cross_slope"),
        surface=row.get("surface"),
        curb_ramp=row.get("curb_ramp"),
        step_free=row.get("step_free"),
        obstacle=bool(row.get("obstacle", row.get("obstacle_state") == "blocked")),
        lighting=row.get("lighting"),
        shelter=row.get("shelter"),
        confidence=float(row.get("confidence", row.get("map_confidence", 1.0))),
        geometry=geom,
        crossing_type=row.get("crossing_type", row.get("edge_type")),
        obstacle_state=row.get("obstacle_state"),
        timestamp_s=row.get("timestamp_s"),
        source=_norm_source(row, fallback_source),
    )


def _reject_synthetic(records: Iterable[Dict[str, Any]], label: str) -> None:
    bad = []
    for r in records:
        src = str(r.get("source") or r.get("evidence_source") or "").lower()
        if src.startswith("synthetic") or "proxy" in src or src in {"toy", "mock"}:
            bad.append((r.get("node_id") or r.get("edge_id") or r.get("id"), src))
    if bad:
        raise RuntimeError(f"--fail_on_synthetic rejects {label}; first examples: {bad[:5]}")


def _episode_ids(value: str | None) -> List[str]:
    return [x.strip() for x in (value or "shared").replace(",", "+").split("+") if x.strip()]


def _graph_node_record(node: AccessibilityNode) -> Dict[str, Any]:
    """Serialize a graph node without dataclasses.asdict deep-copy overhead.

    ``schemas.to_dict`` calls ``asdict`` and then recursively walks the result.
    For millions of graph rows that double traversal is expensive.  Graph node
    fields are JSON-native except the nested Pose2D, so a shallow record plus a
    shallow pose conversion is value-identical and avoids copying large lists.
    """
    row = dict(vars(node))
    pose = row.get("pose")
    if pose is not None and hasattr(pose, "__dict__"):
        row["pose"] = dict(vars(pose))
    return row


def _graph_edge_record(edge: AccessibilityEdge) -> Dict[str, Any]:
    """Value-identical shallow serialization for AccessibilityEdge."""
    return dict(vars(edge))


def _write_graph(out: Path, graph: AccessibilityGraph, compact_storage: bool = False, build_fingerprint: str | None = None) -> Dict[str, Any]:
    """Write one per-episode graph and return compact build metadata.

    ``compact_storage`` avoids serializing nodes/edges a second time inside
    ``<episode>.jsonl``.  PUDO generation reads ``<episode>.meta.json`` for graph
    metadata and the canonical ``.nodes/.edges`` files for topology.
    """
    started = time.perf_counter()
    write_jsonl(out / f"{graph.episode_id}.nodes.jsonl", (_graph_node_record(n) for n in graph.nodes))
    write_jsonl(out / f"{graph.episode_id}.edges.jsonl", (_graph_edge_record(e) for e in graph.edges))
    if compact_storage:
        dump_json(out / f"{graph.episode_id}.meta.json", {"episode_id": graph.episode_id, "metadata": graph.metadata})
        (out / f"{graph.episode_id}.jsonl").unlink(missing_ok=True)
    else:
        write_jsonl(out / f"{graph.episode_id}.jsonl", [to_dict(graph)])
    meta = {
        "status": "PASS", "episode_id": graph.episode_id,
        "source": (graph.metadata or {}).get("source"),
        "nodes": len(graph.nodes), "edges": len(graph.edges),
        "features_cropped": int((graph.metadata or {}).get("features_cropped", 0) or 0),
        "semantic_features_cropped": int((graph.metadata or {}).get("semantic_features_cropped", 0) or 0),
        "high_resolution_elevation_samples_cropped": int((graph.metadata or {}).get("high_resolution_elevation_samples_cropped", 0) or 0),
        "coarse_elevation_samples_ignored_for_local_grade": int((graph.metadata or {}).get("coarse_elevation_samples_ignored_for_local_grade", 0) or 0),
        "dem_point_nodes_inserted": int((graph.metadata or {}).get("dem_point_nodes_inserted", 0) or 0),
        "compact_storage": bool(compact_storage),
        "build_version": GRAPH_BUILD_VERSION,
        "build_fingerprint": build_fingerprint,
        "write_s": time.perf_counter() - started,
    }
    dump_json(out / f"{graph.episode_id}.build.json", meta)
    return meta


def _resume_graph_stats(out: Path, episode_id: str, compact_storage: bool, expected_fingerprint: str | None = None) -> Optional[Dict[str, Any]]:
    marker = out / f"{episode_id}.build.json"
    nodes = out / f"{episode_id}.nodes.jsonl"
    edges = out / f"{episode_id}.edges.jsonl"
    meta = out / f"{episode_id}.meta.json"
    full = out / f"{episode_id}.jsonl"
    if not marker.exists() or not nodes.exists() or not edges.exists():
        return None
    if compact_storage and not meta.exists():
        return None
    if not compact_storage and not full.exists():
        return None
    try:
        payload = json.loads(marker.read_text(encoding="utf-8"))
        if payload.get("status") != "PASS":
            return None
        if payload.get("build_version") != GRAPH_BUILD_VERSION:
            return None
        if expected_fingerprint is not None and payload.get("build_fingerprint") != expected_fingerprint:
            return None
        return payload
    except Exception:
        return None




def _bbox_of_points(points: Iterable[Sequence[float]]) -> Optional[Tuple[float, float, float, float]]:
    xs: List[float] = []
    ys: List[float] = []
    for p in points:
        if len(p) < 2:
            continue
        try:
            xs.append(float(p[0])); ys.append(float(p[1]))
        except Exception:
            continue
    if not xs:
        return None
    return (min(xs), min(ys), max(xs), max(ys))


def _feature_bbox(features: Sequence[Any], attr: str = "geometry") -> Optional[Tuple[float, float, float, float]]:
    pts: List[Sequence[float]] = []
    for f in features:
        pts.extend(getattr(f, attr, []) or [])
    return _bbox_of_points(pts)


def _bbox_overlap(a: Optional[Tuple[float, float, float, float]], b: Optional[Tuple[float, float, float, float]]) -> Optional[bool]:
    if a is None or b is None:
        return None
    return not (a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1])


def _bbox_dict(b: Optional[Tuple[float, float, float, float]]) -> Optional[Dict[str, float]]:
    if b is None:
        return None
    return {"min_x": float(b[0]), "min_y": float(b[1]), "max_x": float(b[2]), "max_y": float(b[3])}


def _spatial_diagnostics(scene: Any, features: Sequence[Any], transformer: CoordinateTransformer) -> Dict[str, Any]:
    cropped = [
        f for f in features
        if scene.bbox is None or any(
            scene.bbox[0] <= float(p[0]) <= scene.bbox[2] and scene.bbox[1] <= float(p[1]) <= scene.bbox[3]
            for p in (getattr(f, "geometry", []) or [])
        )
    ]
    local_bbox = _feature_bbox(features, "geometry")
    wgs_bbox = _feature_bbox(features, "wgs84_geometry")
    route_wgs84: List[List[float]] = []
    for p in getattr(scene, "route_polyline", []) or []:
        if len(p) >= 2:
            try:
                lon, lat = transformer.local_to_wgs84(float(p[0]), float(p[1]))
                route_wgs84.append([lon, lat])
            except Exception:
                pass
    return {
        "episode_id": getattr(scene, "episode_id", None),
        "map_name": getattr(scene, "map_name", None),
        "scene_bbox_local": _bbox_dict(getattr(scene, "bbox", None)),
        "feature_bbox_local": _bbox_dict(local_bbox),
        "feature_bbox_wgs84": _bbox_dict(wgs_bbox),
        "route_bbox_wgs84_from_georef": _bbox_dict(_bbox_of_points(route_wgs84)),
        "features_loaded": len(features),
        "features_inside_scene_bbox": len(cropped),
        "local_bbox_overlaps_scene_bbox": _bbox_overlap(getattr(scene, "bbox", None), local_bbox),
        "georeference_validated": bool(transformer.config.get("validated", False)),
        "georeference_description": transformer.config.get("description"),
        "local_crs": transformer.config.get("local_crs") or transformer.config.get("projected_crs") or transformer.config.get("target_crs"),
        "projected_map_frame": bool(getattr(transformer, "projected_map_frame", False)),
        "transform_backend": getattr(transformer, "transform_backend", "unknown"),
        "hint": "0 cropped features usually means the WGS84->nuPlan map georeference is not aligned, the transform backend is wrong/missing, or the Overpass/city-GIS bbox does not cover this nuPlan map/scenario. For nuPlan DB-set maps whose scene poses look like UTM/easting-northing coordinates, use local_crs plus projected_map_frame=true and check transform_backend is pyproj or utm_fallback.",
    }

def _graph_static_fingerprint(args: argparse.Namespace) -> str:
    """Fingerprint graph semantics + external evidence, excluding scene-list membership.

    A previous global fingerprint included the SHA of the entire scenes.jsonl.
    Adding/removing one independent episode therefore invalidated every existing
    graph shard.  Graph content is actually a function of static evidence/config
    plus *that episode's* route context, so resume is now keyed per episode.
    """
    payload = {
        "version": GRAPH_BUILD_VERSION,
        "source_name": args.source_name,
        "episode_radius_m": float(args.episode_radius_m),
        "corridor_chunk_length_m": float(args.corridor_chunk_length_m),
        "snap_tolerance_m": float(args.snap_tolerance_m),
        "pudo_connector_radius_m": float(args.pudo_connector_radius_m),
        "min_nodes_per_episode": int(args.min_nodes_per_episode),
        "min_edges_per_episode": int(args.min_edges_per_episode),
        "add_bidirectional": not bool(args.no_bidirectional_edges),
        "compact_storage": bool(args.compact_storage),
        "fail_on_synthetic": bool(args.fail_on_synthetic),
    }
    paths = [
        args.georeference_json, args.nodes_jsonl, args.edges_jsonl,
        args.osm_nodes_jsonl, args.osm_edges_jsonl, args.osm_source,
        args.opensidewalks_source, args.city_gis_dir, args.curb_inventory_source,
        args.entrance_source, args.elevation_source,
    ]
    return fingerprint(payload, paths)


def _graph_episode_fingerprint(static_fp: str, scene: Any) -> str:
    # Only fields read by AccessibilityFusionBuilder/build_for_scene are included.
    # Canonical fingerprint serialization makes this stable across process order.
    return fingerprint({
        "static_fingerprint": static_fp,
        "episode_id": str(getattr(scene, "episode_id", "")),
        "map_name": str(getattr(scene, "map_name", "")),
        "route_polyline": getattr(scene, "route_polyline", []) or [],
        "bbox": list(getattr(scene, "bbox", []) or []),
        "corridor_radius_m": float(getattr(scene, "corridor_radius_m", 0.0) or 0.0),
    }, [])


def _build_prepared(args: argparse.Namespace) -> Dict[str, Any]:
    node_rows = _read_json_records(args.nodes_jsonl or args.osm_nodes_jsonl)
    edge_rows = _read_json_records(args.edges_jsonl or args.osm_edges_jsonl)
    if not node_rows or not edge_rows:
        raise RuntimeError("prepared accessibility graph build requires explicit node and edge records")
    if args.fail_on_synthetic:
        _reject_synthetic(node_rows, "nodes")
        _reject_synthetic(edge_rows, "edges")
    nodes = [_node(r, args.source_name) for r in node_rows]
    by_id = {n.node_id: n for n in nodes}
    edges = [_edge(r, args.source_name, by_id) for r in edge_rows]
    if len(nodes) < args.min_nodes_per_episode or len(edges) < args.min_edges_per_episode:
        raise RuntimeError(f"accessibility graph too small: {len(nodes)} nodes/{len(edges)} edges; required {args.min_nodes_per_episode}/{args.min_edges_per_episode}")
    out = Path(args.output_graph_dir)
    out.mkdir(parents=True, exist_ok=True)
    build_fp = _graph_static_fingerprint(args)
    episodes = _episode_ids(args.episode_ids)
    for eid in episodes:
        graph = AccessibilityGraph(eid, nodes, edges, {"source": args.source_name, "builder": "prepared_jsonl_validator", "episode_radius_m": args.episode_radius_m, "snap_tolerance_m": args.snap_tolerance_m})
        episode_fp = fingerprint({"static_fingerprint": build_fp, "episode_id": eid}, [])
        _write_graph(out, graph, compact_storage=bool(getattr(args, "compact_storage", False)), build_fingerprint=episode_fp)
    return {"status": "PASS", "episodes": episodes, "nodes": len(nodes), "edges": len(edges), "source": args.source_name, "mode": "prepared_jsonl", "build_version": GRAPH_BUILD_VERSION, "build_fingerprint": build_fp, "synthetic_rejected": bool(args.fail_on_synthetic)}


_MP_GRAPH_BUILDER = None
_MP_GRAPH_FEATURES = None
_MP_GRAPH_ARGS = None
_MP_GRAPH_OUT = None
_MP_GRAPH_BUILD_FP = None
_MP_GRAPH_TRANSFORMER = None


def _build_one_graph_episode(scene: Any, builder: AccessibilityFusionBuilder, features: List[Any], args: argparse.Namespace, out: Path, static_fp: str, transformer: CoordinateTransformer) -> Dict[str, Any]:
    ep_started = time.perf_counter()
    episode_fp = _graph_episode_fingerprint(static_fp, scene)
    try:
        graph = builder.build_for_scene(
            scene,
            features,
            min_nodes=args.min_nodes_per_episode,
            min_edges=args.min_edges_per_episode,
            add_bidirectional=not args.no_bidirectional_edges,
            pudo_connector_radius_m=args.pudo_connector_radius_m,
        )
    except RuntimeError as exc:
        diag = _spatial_diagnostics(scene, features, transformer)
        if args.diagnostic_report_json:
            # Failure-only path; writing the exact diagnostic remains more
            # useful than silently losing the old report in parallel mode.
            dump_json(args.diagnostic_report_json, {"failed_episode": getattr(scene, "episode_id", None), "diagnostics": [diag]})
        raise RuntimeError(f"{exc}\nSpatial alignment diagnostics: {json.dumps(diag, indent=2, sort_keys=True)}") from exc
    build_s = time.perf_counter() - ep_started
    write_stats = _write_graph(out, graph, compact_storage=args.compact_storage, build_fingerprint=episode_fp)
    graph_timing = (graph.metadata or {}).get("build_timing_s", {}) if isinstance(graph.metadata, dict) else {}
    return {
        "episode_id": graph.episode_id,
        "nodes": len(graph.nodes),
        "edges": len(graph.edges),
        "features_cropped": int((graph.metadata or {}).get("features_cropped", 0) or 0),
        "semantic_features_cropped": int((graph.metadata or {}).get("semantic_features_cropped", 0) or 0),
        "high_resolution_elevation_samples_cropped": int((graph.metadata or {}).get("high_resolution_elevation_samples_cropped", 0) or 0),
        "coarse_elevation_samples_ignored_for_local_grade": int((graph.metadata or {}).get("coarse_elevation_samples_ignored_for_local_grade", 0) or 0),
        "dem_point_nodes_inserted": int((graph.metadata or {}).get("dem_point_nodes_inserted", 0) or 0),
        "build_s": build_s,
        "write_stats": write_stats,
        "graph_timing": graph_timing,
        "total_s": build_s + float(write_stats.get("write_s", 0.0) or 0.0),
    }


def _init_graph_fork_worker() -> None:
    # Rebind the source-id guard after fork. Features/index are inherited
    # copy-on-write and remain read-only, avoiding one 1-2M-feature index build
    # per worker.
    if _MP_GRAPH_BUILDER is not None and _MP_GRAPH_FEATURES is not None:
        _MP_GRAPH_BUILDER._feature_index_source_id = id(_MP_GRAPH_FEATURES)


def _graph_fork_worker(scene: Any) -> Dict[str, Any]:
    return _build_one_graph_episode(
        scene, _MP_GRAPH_BUILDER, _MP_GRAPH_FEATURES, _MP_GRAPH_ARGS,
        _MP_GRAPH_OUT, _MP_GRAPH_BUILD_FP, _MP_GRAPH_TRANSFORMER,
    )


def build_graphs(args: argparse.Namespace) -> Dict[str, Any]:
    has_prepared = bool(args.nodes_jsonl or args.edges_jsonl or args.osm_nodes_jsonl or args.osm_edges_jsonl)
    has_gis = bool(args.osm_source or args.opensidewalks_source or args.city_gis_dir or args.curb_inventory_source or args.entrance_source)
    if has_prepared and not has_gis:
        report = _build_prepared(args)
    else:
        if not has_gis:
            raise RuntimeError("GIS fusion requires --osm_source/--opensidewalks_source/--city_gis_dir/--curb_inventory_source/--entrance_source or prepared node/edge JSONL")
        transformer = CoordinateTransformer.from_file(args.georeference_json)
        features = load_gis_features(
            [args.osm_source, args.opensidewalks_source, args.city_gis_dir, args.curb_inventory_source, args.entrance_source, args.elevation_source],
            transformer,
            args.source_name,
        )
        if args.fail_on_synthetic:
            _reject_synthetic([{"source": f.source, "id": f.feature_id} for f in features], "GIS features")
        if not features:
            raise RuntimeError("GIS fusion found no usable OSM/OpenSidewalks/city GIS features")
        expected_contexts = scene_context_count(args.scene_dataset_dir)
        contexts = iter_scene_contexts(args.scene_dataset_dir, _episode_ids(args.episode_ids), args.episode_radius_m)
        out = Path(args.output_graph_dir)
        out.mkdir(parents=True, exist_ok=True)
        build_fp = _graph_static_fingerprint(args)
        builder = AccessibilityFusionBuilder(
            transformer,
            args.snap_tolerance_m,
            args.source_name,
            corridor_chunk_length_m=args.corridor_chunk_length_m,
        )
        diagnostics: List[Dict[str, Any]] = []
        episode_ids_out: List[str] = []
        timing_rows: List[Dict[str, Any]] = []
        total_nodes = 0
        total_edges = 0
        total_semantic_features_cropped = 0
        total_high_res_dem_samples_cropped = 0
        total_coarse_dem_samples_ignored = 0
        total_dem_point_nodes_inserted = 0
        resumed = 0
        build_breakdown = {"crop_s": 0.0, "topology_s": 0.0, "snap_s": 0.0, "pudo_connector_s": 0.0, "dedupe_s": 0.0, "write_s": 0.0}
        build_started = time.perf_counter()
        worker_count = max(0, int(args.num_workers))
        progress = None if args.disable_tqdm else tqdm(total=expected_contexts, desc="accessibility graphs", unit="episode", mininterval=1.0, dynamic_ncols=True)

        def absorb_result(result: Dict[str, Any]) -> None:
            nonlocal total_nodes, total_edges, total_semantic_features_cropped, total_high_res_dem_samples_cropped, total_coarse_dem_samples_ignored, total_dem_point_nodes_inserted
            write_stats = result["write_stats"]
            graph_timing = result.get("graph_timing") or {}
            for key in ["crop_s", "topology_s", "snap_s", "pudo_connector_s", "dedupe_s"]:
                build_breakdown[key] += float(graph_timing.get(key, 0.0) or 0.0)
            build_breakdown["write_s"] += float(write_stats.get("write_s", 0.0) or 0.0)
            timing_rows.append({**write_stats, "resumed": False, "build_s": result["build_s"], "total_s": result["total_s"]})
            timing_rows[:] = sorted(timing_rows, key=lambda x: float(x.get("total_s", 0.0)), reverse=True)[:50]
            episode_ids_out.append(str(result["episode_id"]))
            total_nodes += int(result["nodes"])
            total_edges += int(result["edges"])
            total_semantic_features_cropped += int(result.get("semantic_features_cropped", 0) or 0)
            total_high_res_dem_samples_cropped += int(result.get("high_resolution_elevation_samples_cropped", 0) or 0)
            total_coarse_dem_samples_ignored += int(result.get("coarse_elevation_samples_ignored_for_local_grade", 0) or 0)
            total_dem_point_nodes_inserted += int(result.get("dem_point_nodes_inserted", 0) or 0)
            if progress is not None:
                progress.update(1)
                progress.set_postfix(nodes=result["nodes"], edges=result["edges"], cropped=result["features_cropped"], workers=max(1, worker_count), refresh=False)

        def absorb_resume(scene: Any, resume_stats: Dict[str, Any]) -> None:
            nonlocal total_nodes, total_edges, total_semantic_features_cropped, total_high_res_dem_samples_cropped, total_coarse_dem_samples_ignored, total_dem_point_nodes_inserted, resumed
            episode_ids_out.append(scene.episode_id)
            total_nodes += int(resume_stats.get("nodes", 0) or 0)
            total_edges += int(resume_stats.get("edges", 0) or 0)
            total_semantic_features_cropped += int(resume_stats.get("semantic_features_cropped", 0) or 0)
            total_high_res_dem_samples_cropped += int(resume_stats.get("high_resolution_elevation_samples_cropped", 0) or 0)
            total_coarse_dem_samples_ignored += int(resume_stats.get("coarse_elevation_samples_ignored_for_local_grade", 0) or 0)
            total_dem_point_nodes_inserted += int(resume_stats.get("dem_point_nodes_inserted", 0) or 0)
            resumed += 1
            if progress is not None:
                progress.update(1)
                progress.set_postfix(resumed=resumed, workers=max(1, worker_count), refresh=False)

        if worker_count > 1 and hasattr(mp, "get_context"):
            # Build the million-feature bounds index once *before* fork so all
            # workers share it copy-on-write. Graph/PUDO calibration showed graph
            # CPU at ~1 core and near-zero iowait, making process-level episode
            # parallelism both safe and materially useful on the 48-core host.
            if builder._feature_index is None:
                builder._feature_index = GISFeatureSpatialIndex(features)
                builder._feature_index_source_id = id(features)
            global _MP_GRAPH_BUILDER, _MP_GRAPH_FEATURES, _MP_GRAPH_ARGS, _MP_GRAPH_OUT, _MP_GRAPH_BUILD_FP, _MP_GRAPH_TRANSFORMER
            _MP_GRAPH_BUILDER = builder; _MP_GRAPH_FEATURES = features; _MP_GRAPH_ARGS = args
            _MP_GRAPH_OUT = out; _MP_GRAPH_BUILD_FP = build_fp; _MP_GRAPH_TRANSFORMER = transformer
            try:
                ctx = mp.get_context("fork")
            except ValueError:
                ctx = None
            if ctx is None:
                worker_count = 0
            else:
                batch_size = max(4, worker_count * 4)
                with ctx.Pool(processes=worker_count, initializer=_init_graph_fork_worker) as pool:
                    pending: List[Any] = []
                    for scene in contexts:
                        resume_stats = _resume_graph_stats(out, scene.episode_id, args.compact_storage, _graph_episode_fingerprint(build_fp, scene)) if args.resume else None
                        if resume_stats is not None:
                            absorb_resume(scene, resume_stats)
                            continue
                        pending.append(scene)
                        if len(pending) >= batch_size:
                            for result in pool.map(_graph_fork_worker, pending, chunksize=1):
                                absorb_result(result)
                            pending.clear()
                    if pending:
                        for result in pool.map(_graph_fork_worker, pending, chunksize=1):
                            absorb_result(result)
        if worker_count <= 1:
            for scene in contexts:
                resume_stats = _resume_graph_stats(out, scene.episode_id, args.compact_storage, _graph_episode_fingerprint(build_fp, scene)) if args.resume else None
                if resume_stats is not None:
                    absorb_resume(scene, resume_stats)
                    continue
                result = _build_one_graph_episode(scene, builder, features, args, out, build_fp, transformer)
                absorb_result(result)
        if progress is not None:
            progress.close()
        build_elapsed = time.perf_counter() - build_started
        report = {
            "episode_count": len(episode_ids_out),
            "episode_id_sample": episode_ids_out[:20],
            "nodes": total_nodes,
            "edges": total_edges,
            "source": args.source_name,
            "mode": "gis_fusion",
            "build_version": GRAPH_BUILD_VERSION,
            "build_fingerprint": build_fp,
            "fingerprint_scope": "static_evidence_plus_per_episode_route_context",
            "features_loaded": len(features),
            "semantic_features_cropped_total": total_semantic_features_cropped,
            "high_resolution_elevation_samples_cropped_total": total_high_res_dem_samples_cropped,
            "coarse_elevation_samples_ignored_for_local_grade_total": total_coarse_dem_samples_ignored,
            "dem_point_nodes_inserted_total": total_dem_point_nodes_inserted,
            "dem_integration_semantics": "<=5m DEM is nearest-sampled onto semantic pedestrian nodes for derived endpoint grade; coarser DEM/DSM is not used as sidewalk-scale grade; DEM samples are never graph vertices",
            "resumed_episodes": resumed,
            "compact_storage": bool(args.compact_storage),
            "elapsed_s": build_elapsed,
            "episodes_per_s": len(episode_ids_out) / max(build_elapsed, 1e-9),
            "performance_breakdown_s": build_breakdown,
            "corridor_chunk_length_m": float(args.corridor_chunk_length_m),
            "episode_workers": max(1, int(args.num_workers)),
            "synthetic_rejected": bool(args.fail_on_synthetic),
            "georeference": args.georeference_json,
            "georeference_validated": bool(transformer.config.get("validated", False)),
            "transform_backend": getattr(transformer, "transform_backend", "unknown"),
            "projected_map_frame": bool(getattr(transformer, "projected_map_frame", False)),
            "spatial_alignment_validated": True,
            "status": "PASS",
        }
        if args.timing_report_json:
            dump_json(args.timing_report_json, {
                "status": "PASS", "summary": report,
                "slowest_episodes": timing_rows,
                "note": "Detailed per-episode timings remain in <episode>.build.json; this report is intentionally compact.",
            })
    out = Path(args.output_graph_dir)
    source_report = Path(args.source_report_json) if args.source_report_json else out / "source_report.json"
    quality_report = Path(args.quality_report_json) if args.quality_report_json else out / "quality_report.json"
    dump_json(source_report, report)
    dump_json(quality_report, {"min_nodes_per_episode": args.min_nodes_per_episode, "min_edges_per_episode": args.min_edges_per_episode, **report})
    return report


def main() -> None:
    p = argparse.ArgumentParser(description="Build AbilityBench-AV accessibility graphs by fusing nuPlan scene corridors with OSM/OpenSidewalks/city sidewalk GIS.")
    p.add_argument("--scene_dataset_dir", default=None, help="Directory containing scenes.jsonl/episodes.jsonl used for episode IDs, route corridor, and scenario bbox cropping.")
    p.add_argument("--nuplan_map_root", default=None, help="Accepted for pipeline compatibility; nuPlan HD map semantics are supplied through scene metadata/map API during dataset build.")
    p.add_argument("--nuplan_map_version", default=None)
    p.add_argument("--georeference_json", default=None, help="JSON/YAML with origin_lat/origin_lon/origin_heading_deg or local_crs for nuPlan local frame <-> WGS84 conversion.")
    p.add_argument("--osm_source", default=None, help="OSM/Overpass JSON, OSM-derived GeoJSON/JSONL, or directory of such files.")
    p.add_argument("--opensidewalks_source", default=None, help="OpenSidewalks GeoJSON/JSONL/JSON export.")
    p.add_argument("--city_gis_dir", default=None, help="Directory or file containing city sidewalk/crosswalk/curb ramp GIS layers.")
    p.add_argument("--curb_inventory_source", default=None, help="City curb/PUDO inventory records with curb height, landing width, clearance, or regulation tags.")
    p.add_argument("--entrance_source", default=None, help="Building/POI entrance point layer; entrances are snapped to pedestrian topology.")
    p.add_argument("--elevation_source", default=None, help="DEM/elevation point/line export; endpoint elevations are used to derive missing slopes when possible.")
    p.add_argument("--nodes_jsonl", default=None, help="Prepared real accessibility nodes JSONL/JSON; used only when GIS sources are absent.")
    p.add_argument("--edges_jsonl", default=None, help="Prepared real accessibility edges JSONL/JSON; used only when GIS sources are absent.")
    p.add_argument("--osm_nodes_jsonl", default=None, help="Alias for prepared OSM/OpenSidewalks node records.")
    p.add_argument("--osm_edges_jsonl", default=None, help="Alias for prepared OSM/OpenSidewalks edge records.")
    p.add_argument("--output_graph_dir", required=True)
    p.add_argument("--episode_ids", default="shared")
    p.add_argument("--episode_radius_m", type=float, default=800.0, help="Buffer around route corridor for per-scenario crop.")
    p.add_argument("--corridor_chunk_length_m", type=float, default=1000.0, help="Length of conservative route-envelope chunks used to avoid irrelevant corners of one global bbox without dropping any feature that could lie inside the configured route buffer.")
    p.add_argument("--snap_tolerance_m", type=float, default=3.0)
    p.add_argument("--pudo_connector_radius_m", type=float, default=75.0, help="Distance from route corridor for curb/curb-ramp nodes marked as PUDO connector candidates.")
    p.add_argument("--min_nodes_per_episode", type=int, default=100)
    p.add_argument("--min_edges_per_episode", type=int, default=150)
    p.add_argument("--source_name", default="nuplan_osm_opensidewalks_citygis")
    p.add_argument("--fail_on_synthetic", action="store_true")
    p.add_argument("--no_bidirectional_edges", action="store_true")
    p.add_argument("--num_workers", type=int, default=0, help="Parallel graph episode worker processes on Linux. Workers share the prebuilt city GIS index via fork copy-on-write; 0/1 is sequential.")
    p.add_argument("--disable_tqdm", action="store_true", help="Disable per-episode progress bars.")
    p.add_argument("--compact_storage", action="store_true", help="Write nodes/edges plus lightweight metadata instead of duplicating the full graph in <episode>.jsonl.")
    p.add_argument("--resume", action="store_true", help="Skip episodes with a complete .build.json marker and matching graph files.")
    p.add_argument("--timing_report_json", default=None, help="Optional per-episode build/write timing report.")
    p.add_argument("--diagnostic_report_json", default=None, help="Optional path for spatial/georeference diagnostics on failure.")
    p.add_argument("--source_report_json", default=None, help="Optional per-city source report path; avoids overwriting reports when several cities share an output graph directory.")
    p.add_argument("--quality_report_json", default=None, help="Optional per-city graph quality report path.")
    args = p.parse_args()
    report = build_graphs(args)
    print(json.dumps(report, indent=2, sort_keys=True))
    print(f"ACCESSIBILITY_GRAPH_CHECK={report.get('status', 'PASS')}")


if __name__ == "__main__":
    main()
